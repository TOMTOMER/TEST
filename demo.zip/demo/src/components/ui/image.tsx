export { default } from 'next/image';
