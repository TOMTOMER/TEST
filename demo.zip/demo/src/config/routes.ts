const routes = {
  home: '/',
  swap: '/swap',
  liquidity: '/liquidity',
  liquidityPosition: '/liquidity-position',
  farms: '/farms',
  createNft: '/create-nft',
  nftDetails: '/nft-details',
  search: '/search',
  notification: '/notifications',
  vote: '/vote',
  proposals: '/proposals',
  createProposal: '/proposals/create',
  charts: '/charts',
  profile: '/profile',
  portfolio: '/profile?view=portfolio',
  history: '/profile?view=history',
};

export default routes;
