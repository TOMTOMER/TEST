export enum LAYOUT_OPTIONS {
  MODERN = 'Modern',
  MINIMAL = 'Minimal',
  RETRO = 'Retro',
  CLASSIC = 'Classic',
}
